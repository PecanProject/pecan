library("testthat")
test_check("nneo")
