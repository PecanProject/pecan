#!/bin/bash -l

# create output folder
mkdir -p "/groups/dlebauer/ed2_results/pecan_remote/2022-09-02-16-49-50/out/ENS-00001-76"
# no need to mkdir for scratch

# redirect output
exec 3>&1
exec &>> "/groups/dlebauer/ed2_results/pecan_remote/2022-09-02-16-49-50/out/ENS-00001-76/logfile.txt"

TIMESTAMP=`date +%Y/%m/%d_%H:%M:%S`
echo "Logging on "$TIMESTAMP

# host specific setup

module load openmpi3

# @REMOVE_HISTXML@ : tag to remove "history.xml" on remote for restarts, commented out on purpose


# flag needed for ubuntu
export GFORTRAN_UNBUFFERED_PRECONNECTED=yes

# see if application needs running
if [ ! -e "/groups/dlebauer/ed2_results/pecan_remote/2022-09-02-16-49-50/out/ENS-00001-76/history.xml" ]; then
  cd "/groups/dlebauer/ed2_results/pecan_remote/2022-09-02-16-49-50/run/ENS-00001-76"
  
  "/groups/dlebauer/ed2_results/global_inputs/ed2_2.2.0_singularity.sh" ""
  STATUS=$?
  if [ $STATUS == 0 ]; then
    if grep -Fq '=== Time integration ends; Total elapsed time=' "/groups/dlebauer/ed2_results/pecan_remote/2022-09-02-16-49-50/out/ENS-00001-76/logfile.txt"; then
      STATUS=0
    else
      STATUS=1
    fi
  fi
  
  # copy scratch if needed
  # no need to copy from scratch
  # no need to clear scratch

  # check the status
  if [ $STATUS -ne 0 ]; then
  	echo -e "ERROR IN MODEL RUN\nLogfile is located at '/groups/dlebauer/ed2_results/pecan_remote/2022-09-02-16-49-50/out/ENS-00001-76/logfile.txt'"
  	echo "************************************************* End Log $TIMESTAMP"
    echo ""
  	exit $STATUS
  fi

  # convert to MsTMIP
  Rscript \
    -e "library(PEcAn.ED2)" \
    -e "model2netcdf.ED2('/groups/dlebauer/ed2_results/pecan_remote/2022-09-02-16-49-50/out/ENS-00001-76', 40.0637, -88.202, '2004-07-01', '2004-08-01', c(SetariaWT = 1L, ebifarm.c3grass = 5L))"
  STATUS=$?
  if [ $STATUS -ne 0 ]; then
  	echo -e "ERROR IN model2netcdf.ED2\nLogfile is located at '/groups/dlebauer/ed2_results/pecan_remote/2022-09-02-16-49-50/out/ENS-00001-76'/logfile.txt"
  	echo "************************************************* End Log $TIMESTAMP"
    echo ""
    exit $STATUS
  fi
fi

# copy readme with specs to output
cp  "/groups/dlebauer/ed2_results/pecan_remote/2022-09-02-16-49-50/run/ENS-00001-76/README.txt" "/groups/dlebauer/ed2_results/pecan_remote/2022-09-02-16-49-50/out/ENS-00001-76/README.txt"

# run getdata to extract right variables

# host specific teardown


# all done
echo -e "MODEL FINISHED\nLogfile is located at '/groups/dlebauer/ed2_results/pecan_remote/2022-09-02-16-49-50/out/ENS-00001-76/logfile.txt'"
echo "************************************************* End Log $TIMESTAMP"
echo ""
