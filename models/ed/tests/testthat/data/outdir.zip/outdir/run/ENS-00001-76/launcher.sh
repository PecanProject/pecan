#!/bin/bash
module load openmpi3; mpirun /groups/dlebauer/ed2_results/pecan/contrib/modellauncher/modellauncher /groups/dlebauer/ed2_results/pecan_remote/2022-09-02-16-49-50/run/ENS-00001-76/joblist.txt
