runtype     : ensemble
 workflow id :  2022-09-02-16-49-50 
 ensemble id :  NA 
 run         :  1 / 1 
 run id      :  ENS-00001-76 
 pft names   :  SetariaWT ebifarm.c3grass 
 model       :  ED2 
 model id    :  14 
 site        :  EBI Energy farm 
 site  id    :  76 
 met data    :  /data/sites/ebifarm/ED_MET_DRIVER_HEADER 
 start date  :  2004-07-01 
 end date    :  2004-08-01 
 hostname    :  puma 
 rundir      :  /groups/dlebauer/ed2_results/pecan_remote/2022-09-02-16-49-50/run/ENS-00001-76 
 outdir      :  /groups/dlebauer/ed2_results/pecan_remote/2022-09-02-16-49-50/out/ENS-00001-76 
